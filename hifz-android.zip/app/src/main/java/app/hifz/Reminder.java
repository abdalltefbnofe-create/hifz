package app.hifz;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Calendar;

/**
 * Reminder logic. The page sends a snapshot: the due time of every studied card,
 * plus the new cards still allowed today. From that we know when the pending
 * count reaches the threshold, even while the app is closed.
 */
final class Reminder {

    private static final String PREFS = "reminder";
    private static final String KEY_DATA = "data";
    private static final String KEY_LAST = "lastDay";
    private static final String KEY_LASTP = "lastProj";
    private static final String CHANNEL = "due_cards";
    private static final int NOTIFICATION_ID = 7;
    private static final int ALARM_CODE = 11;
    private static final int START_HOUR = 9;
    private static final int END_HOUR = 22;
    private static final long MIN_DELAY_MS = 5L * 60L * 1000L;
    /** Minimum gap between two alerts about memorization-project cards. */
    private static final long PROJ_GAP_MS = 3L * 60L * 60L * 1000L;

    private Reminder() {
    }

    static String dayKey(Calendar c) {
        return c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONObject load(Context ctx) {
        String s = prefs(ctx).getString(KEY_DATA, null);
        if (s == null) {
            return null;
        }
        try {
            return new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    /** New cards the user may still study today (or on the day of {@code cal}). */
    private static int newAvailable(JSONObject o, Calendar cal) {
        JSONArray nw = o.optJSONArray("nw");
        if (nw == null) {
            return 0;
        }
        boolean sameDay = dayKey(cal).equals(o.optString("day"));
        int total = 0;
        for (int i = 0; i < nw.length(); i++) {
            JSONArray e = nw.optJSONArray(i);
            if (e == null) {
                continue;
            }
            int fresh = e.optInt(0, 0);
            int perDay = e.optInt(1, 20);
            int used = e.optInt(2, 0);
            int left = sameDay ? perDay - used : perDay;
            total += Math.max(0, Math.min(fresh, left));
        }
        return total;
    }

    private static long[] readTimes(JSONObject o, String key) {
        JSONArray a = o.optJSONArray(key);
        if (a == null) {
            return new long[0];
        }
        long[] r = new long[a.length()];
        for (int i = 0; i < r.length; i++) {
            r[i] = a.optLong(i, Long.MAX_VALUE);
        }
        Arrays.sort(r);
        return r;
    }

    /** Moments (ordinary decks and projects together) when a studied card becomes waiting. */
    private static long[] sortedDues(JSONObject o) {
        long[] a = readTimes(o, "dues");
        long[] b = readTimes(o, "pd");
        long[] r = Arrays.copyOf(a, a.length + b.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        Arrays.sort(r);
        return r;
    }

    private static int projWaiting(JSONObject o, long now) {
        int n = 0;
        for (long d : readTimes(o, "pd")) {
            if (d <= now) {
                n++;
            }
        }
        return n;
    }

    /** Earliest moment a project alert may fire, or -1 when alerts are off or nothing is coming. */
    private static long projTime(JSONObject o, long now, long lastProj) {
        if (!o.optBoolean("pj", true)) {
            return -1;
        }
        long[] p = readTimes(o, "pd");
        if (p.length == 0) {
            return -1;
        }
        long t = Math.max(p[0], now);
        if (lastProj > 0) {
            t = Math.max(t, lastProj + PROJ_GAP_MS);
        }
        return t;
    }

    private static int countNow(JSONObject o, long now, Calendar cal) {
        int n = newAvailable(o, cal);
        for (long d : sortedDues(o)) {
            if (d <= now) {
                n++;
            }
        }
        return n;
    }

    /** Earliest moment the pending count reaches the threshold, or -1 if never. */
    private static long reachTime(JSONObject o, long now, Calendar cal) {
        int need = o.optInt("n", 10) - newAvailable(o, cal);
        if (need <= 0) {
            return now;
        }
        long[] dues = sortedDues(o);
        if (dues.length < need) {
            return -1;
        }
        return Math.max(now, dues[need - 1]);
    }

    private static void setHour(Calendar c, int hour) {
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }

    /** Moves a time into the allowed window and skips a day already notified. */
    private static long intoWindow(long t, String lastDay) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        int h = c.get(Calendar.HOUR_OF_DAY);
        if (lastDay.equals(dayKey(c)) || h >= END_HOUR) {
            c.add(Calendar.DAY_OF_YEAR, 1);
            setHour(c, START_HOUR);
        } else if (h < START_HOUR) {
            setHour(c, START_HOUR);
        }
        return c.getTimeInMillis();
    }

    private static PendingIntent alarmIntent(Context ctx) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        return PendingIntent.getBroadcast(ctx, ALARM_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Called by the page whenever cards or settings change. */
    static void save(Context ctx, String json) {
        prefs(ctx).edit().putString(KEY_DATA, json).apply();
        JSONObject o = load(ctx);
        if (o != null && countNow(o, System.currentTimeMillis(), Calendar.getInstance()) == 0) {
            dismiss(ctx);
        }
        schedule(ctx);
        DueWidget.refresh(ctx);
    }

    /** {cards waiting now, current streak, 1 if the app has sent data}. */
    static int[] summary(Context ctx) {
        JSONObject o = load(ctx);
        if (o == null) {
            return new int[]{0, 0, 0};
        }
        Calendar now = Calendar.getInstance();
        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);
        String day = o.optString("day");
        boolean streakAlive = day.equals(dayKey(now)) || day.equals(dayKey(yesterday));
        return new int[]{countNow(o, System.currentTimeMillis(), now),
                streakAlive ? o.optInt("streak", 0) : 0, 1};
    }

    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        PendingIntent pi = alarmIntent(ctx);
        am.cancel(pi);
        JSONObject o = load(ctx);
        if (o == null || !o.optBoolean("on", true)) {
            return;
        }
        long now = System.currentTimeMillis();
        long earliest = now + MIN_DELAY_MS;
        long best = -1;
        long t = reachTime(o, now, Calendar.getInstance());
        if (t >= 0) {
            best = intoWindow(Math.max(t, earliest), prefs(ctx).getString(KEY_LAST, ""));
        }
        long pt = projTime(o, now, prefs(ctx).getLong(KEY_LASTP, 0L));
        if (pt >= 0) {
            pt = intoWindow(Math.max(pt, earliest), "");
            if (best < 0 || pt < best) {
                best = pt;
            }
        }
        if (best < 0) {
            return;
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
    }

    /** Runs when the alarm fires. */
    static void check(Context ctx) {
        JSONObject o = load(ctx);
        if (o != null && o.optBoolean("on", true)) {
            long now = System.currentTimeMillis();
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            String today = dayKey(cal);
            SharedPreferences p = prefs(ctx);
            int count = countNow(o, now, cal);
            int proj = projWaiting(o, now);
            boolean inWindow = hour >= START_HOUR && hour < END_HOUR;
            boolean byCount = count >= o.optInt("n", 10)
                    && !today.equals(p.getString(KEY_LAST, ""));
            long lastP = p.getLong(KEY_LASTP, 0L);
            boolean byProject = o.optBoolean("pj", true) && proj > 0
                    && (lastP <= 0 || now - lastP >= PROJ_GAP_MS - 60000L);
            if (inWindow && (byCount || byProject) && !MainActivity.visible) {
                notifyUser(ctx, count, proj);
                SharedPreferences.Editor e = p.edit();
                if (byCount) {
                    e.putString(KEY_LAST, today);
                }
                if (proj > 0) {
                    e.putLong(KEY_LASTP, now);
                }
                e.apply();
            }
        }
        schedule(ctx);
        DueWidget.refresh(ctx);
    }

    /** Removes the reminder from the notification shade (the cards were reviewed or the app opened). */
    static void dismiss(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(NOTIFICATION_ID);
        }
    }

    private static boolean notifyUser(Context ctx, int count, int proj) {
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "تذكير المراجعة", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CHANNEL)
                : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("حان وقت المراجعة")
                .setContentText(proj > 0 && proj == count
                        ? "بطاقات مشروع الحفظ تنتظرك: " + proj
                        : "عندك " + count + " بطاقة تنتظر المراجعة"
                        + (proj > 0 ? " (منها " + proj + " من مشاريع الحفظ)" : ""))
                .setContentIntent(content)
                .setAutoCancel(true);
        nm.notify(NOTIFICATION_ID, b.build());
        return true;
    }
}
