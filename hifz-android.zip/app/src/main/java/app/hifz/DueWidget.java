package app.hifz;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Home-screen widget: how many cards are waiting, and the streak. */
public class DueWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            update(context, manager, id);
        }
    }

    /** Redraws every placed widget; called whenever the app sends fresh data. */
    static void refresh(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, DueWidget.class));
            for (int id : ids) {
                update(context, manager, id);
            }
        } catch (Exception ignored) {
        }
    }

    static String[] lines(int[] s) {
        int count = s[0];
        int streak = s[1];
        boolean hasData = s[2] == 1;
        if (!hasData) {
            return new String[]{"دفتر الحفظ", "افتح التطبيق مرة لتفعيل الأداة", ""};
        }
        if (count > 0) {
            return new String[]{String.valueOf(count), "بطاقة تنتظر مراجعتك",
                    streak > 0 ? "سلسلتك " + streak + " يوم، حافظ عليها" : "ابدأ سلسلتك اليوم"};
        }
        return new String[]{"أحسنت", "لا توجد بطاقات الآن",
                streak > 0 ? "سلسلتك " + streak + " يوم" : "استمر على هذا"};
    }

    private static void update(Context context, AppWidgetManager manager, int id) {
        String[] t = lines(Reminder.summary(context));
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_count, t[0]);
        v.setTextViewText(R.id.w_label, t[1]);
        v.setTextViewText(R.id.w_note, t[2]);
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, pi);
        manager.updateAppWidget(id, v);
    }
}
